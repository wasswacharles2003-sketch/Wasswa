function orderFruit(fruitName) {
    alert("Thank you for your interest in " + fruitName +
          "! Please contact us to complete your order.");
}
