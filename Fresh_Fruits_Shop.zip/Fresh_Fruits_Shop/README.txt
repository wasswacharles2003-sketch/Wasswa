FRESH FRUITS SHOP - COURSEWORK PROJECT

Folder contents:
- index.html       Main website page
- css/style.css    Website design and colours
- js/script.js     Order button behaviour
- images/          Folder for any fruit pictures you add later

HOW TO RUN:
1. Extract this folder if you downloaded the ZIP file.
2. Open the Fresh_Fruits_Shop folder.
3. Open index.html with Chrome or another web browser.

NOTES:
- The fruit prices and contact details are examples. Change them before submitting.
- The fruit illustrations are emoji, so no internet connection is needed to display them.
- The Order Now buttons show a demonstration message; they do not submit a real order.
